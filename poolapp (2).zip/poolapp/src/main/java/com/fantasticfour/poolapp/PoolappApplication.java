package com.fantasticfour.poolapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoolappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PoolappApplication.class, args);
	}

}
