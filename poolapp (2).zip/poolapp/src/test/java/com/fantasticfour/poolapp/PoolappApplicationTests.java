package com.fantasticfour.poolapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoolappApplicationTests {

	@Test
	void contextLoads() {
	}

}
